# 💌 mailgo Firefox addon

Official mailgo Firefox addon

https://addons.mozilla.org/it/firefox/addon/mailgo/
